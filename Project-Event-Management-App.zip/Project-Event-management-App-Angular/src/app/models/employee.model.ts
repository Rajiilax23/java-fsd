export class User {
  firstName!: string;
  lastName!: string;
  email!: string;
  mobile!: number;
  address!: string;
  zipcode!: number;
  bloodgroup!:string;
  dateofbirth!: string;
  gender!: string;
  maritalstatus!: string;
  id!: number;
}
