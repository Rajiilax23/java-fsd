import { User } from '../models/employee.model';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-create-registration',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  selectedGender!: string;
  genders: string[] = ["Male", "Female"];
  
  employeeForm!: FormGroup;
  private userIdToUpdate!: number;
  public isUpdateActive: boolean = false;

  constructor(private fb: FormBuilder, private api: ApiService, private toastService: NgToastService, private activatedRoute: ActivatedRoute, private router: Router) {

  }
  ngOnInit(): void {
    this.employeeForm = this.fb.group({
      firstName: [''],
      lastName: [''],
      email: [''],
      mobile: [''],
      address: [''],
      zipcode: [''],
      bloodgroup: [''],
      dateofbirth: [''],
      gender: [''],
      maritalstatus: ['']
    });

   this.activatedRoute.params.subscribe(val => {
      this.userIdToUpdate = val['id'];
      if (this.userIdToUpdate) {
        this.isUpdateActive = true;
        this.api.getRegisteredUserId(this.userIdToUpdate)
          .subscribe({
            next: (res) => {
              this.fillFormToUpdate(res);
            },
            error: (err) => {
              console.log(err);
            }
          })
      }
    })
  }
  submit() {
    this.api.postRegistration(this.employeeForm.value)
      .subscribe(res => {
        this.toastService.success({ detail: 'SUCCESS', summary: 'Employee Added Successful', duration: 3000 });
        this.employeeForm.reset();
      });
  }

  fillFormToUpdate(user: User) {
    this.employeeForm.setValue({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      mobile: user.mobile,
      address: user.address,
      zipcode: user.zipcode,
      bloodgroup: user.bloodgroup,
      dateofbirth: user.dateofbirth,
      gender: user.gender,
      maritalstatus: user.maritalstatus
      
      
      
    })
  }

  update() {
    this.api.updateRegisterUser(this.employeeForm.value, this.userIdToUpdate)
      .subscribe(res => {
        this.toastService.success({ detail: 'SUCCESS', summary: 'Employee Details Updated Successful', duration: 3000 });
        this.router.navigate(['list']);
        this.employeeForm.reset();
      });
  }

  

}
